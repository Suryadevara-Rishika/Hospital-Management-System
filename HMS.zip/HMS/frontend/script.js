/**
 * ============================================================
 * MediCare HMS - Hospital Management System Frontend
 * ============================================================
 *
 * This file uses SAMPLE DATA for demo purposes.
 * All API functions below are placeholders — replace their bodies
 * with fetch() calls to your Java backend when REST endpoints
 * (Servlets, Spring Boot controllers, etc.) are available.
 *
 * Backend package: com.learnJDBC
 * Database: MySQL (hospital)
 *
 * Expected DB columns:
 *   patients:     id, name, age, gender
 *   doctors:      id, name, specilization  (matches backend spelling)
 *   appointments: id, patients_id, doctor_id, appointment_date
 * ============================================================
 */

/* --- API Base URL (configure when backend is ready) --- */
const API_BASE_URL = 'http://localhost:8080/api';
// Example endpoints you might expose later:
// GET    /api/patients
// POST   /api/patients
// PUT    /api/patients/{id}
// DELETE /api/patients/{id}
// GET    /api/doctors
// POST   /api/doctors
// PUT    /api/doctors/{id}
// DELETE /api/doctors/{id}
// GET    /api/appointments
// POST   /api/appointments

/* ============================================================
   SAMPLE DATA (mirrors MySQL schema from Java backend)
   Remove or replace once backend integration is complete.
   ============================================================ */
let samplePatients = [
  { id: 1, name: 'Rishika Sharma', age: 28, gender: 'Female' },
  { id: 2, name: 'Arjun Patel', age: 45, gender: 'Male' },
  { id: 3, name: 'Meera Iyer', age: 62, gender: 'Female' },
  { id: 4, name: 'Vikram Singh', age: 33, gender: 'Male' },
  { id: 5, name: 'Ananya Reddy', age: 19, gender: 'Female' }
];

let sampleDoctors = [
  { id: 1, name: 'Dr. Rajesh Kumar', specilization: 'Cardiology' },
  { id: 2, name: 'Dr. Priya Nair', specilization: 'Neurology' },
  { id: 3, name: 'Dr. Amit Desai', specilization: 'Orthopedics' },
  { id: 4, name: 'Dr. Sunita Rao', specilization: 'Pediatrics' }
];

let sampleAppointments = [
  {
    id: 1,
    patients_id: 1,
    doctor_id: 1,
    appointment_date: '2026-06-20',
    patientName: 'Rishika Sharma',
    doctorName: 'Dr. Rajesh Kumar'
  },
  {
    id: 2,
    patients_id: 2,
    doctor_id: 2,
    appointment_date: '2026-06-22',
    patientName: 'Arjun Patel',
    doctorName: 'Dr. Priya Nair'
  },
  {
    id: 3,
    patients_id: 3,
    doctor_id: 3,
    appointment_date: '2026-06-25',
    patientName: 'Meera Iyer',
    doctorName: 'Dr. Amit Desai'
  }
];

/* --- In-memory counters for demo ID generation --- */
let nextPatientId = 6;
let nextDoctorId = 5;
let nextAppointmentId = 4;

/* --- Application state --- */
let deleteCallback = null;

/* ============================================================
   BACKEND API PLACEHOLDER FUNCTIONS
   Replace demo logic with real HTTP calls when integrating.
   ============================================================ */

/**
 * Fetch all patients from backend.
 * Java integration: call REST GET /api/patients or Servlet equivalent.
 * @returns {Promise<Array<{id: number, name: string, age: number, gender: string}>>}
 */
async function fetchPatients() {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/patients`)
  //   .then(res => { if (!res.ok) throw new Error('Failed to fetch patients'); return res.json(); });

  return Promise.resolve([...samplePatients]);
}

/**
 * Add a new patient.
 * Java integration: POST /api/patients with JSON body { name, age, gender }
 * Maps to Patient.addPatient() JDBC insert.
 * @param {{ name: string, age: number, gender: string }} patientData
 * @returns {Promise<Object>}
 */
async function addPatient(patientData) {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/patients`, {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(patientData)
  // }).then(res => res.json());

  const newPatient = { id: nextPatientId++, ...patientData };
  samplePatients.push(newPatient);
  return Promise.resolve(newPatient);
}

/**
 * Update an existing patient.
 * Java integration: PUT /api/patients/{id} (requires new backend method).
 * @param {number} id
 * @param {{ name: string, age: number, gender: string }} patientData
 * @returns {Promise<Object>}
 */
async function updatePatient(id, patientData) {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/patients/${id}`, {
  //   method: 'PUT',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(patientData)
  // }).then(res => res.json());

  const index = samplePatients.findIndex(p => p.id === id);
  if (index === -1) throw new Error('Patient not found');
  samplePatients[index] = { id, ...patientData };
  return Promise.resolve(samplePatients[index]);
}

/**
 * Delete a patient by ID.
 * Java integration: DELETE /api/patients/{id} (requires new backend method).
 * @param {number} id
 * @returns {Promise<boolean>}
 */
async function deletePatient(id) {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/patients/${id}`, { method: 'DELETE' })
  //   .then(res => res.ok);

  const index = samplePatients.findIndex(p => p.id === id);
  if (index === -1) throw new Error('Patient not found');
  samplePatients.splice(index, 1);
  return Promise.resolve(true);
}

/**
 * Fetch all doctors from backend.
 * Java integration: GET /api/doctors — maps to Doctor.viewDoctors().
 * @returns {Promise<Array<{id: number, name: string, specilization: string}>>}
 */
async function fetchDoctors() {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/doctors`)
  //   .then(res => { if (!res.ok) throw new Error('Failed to fetch doctors'); return res.json(); });

  return Promise.resolve([...sampleDoctors]);
}

/**
 * Add a new doctor.
 * Java integration: POST /api/doctors (requires new backend method).
 * @param {{ name: string, specilization: string }} doctorData
 * @returns {Promise<Object>}
 */
async function addDoctor(doctorData) {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/doctors`, {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(doctorData)
  // }).then(res => res.json());

  const newDoctor = { id: nextDoctorId++, ...doctorData };
  sampleDoctors.push(newDoctor);
  return Promise.resolve(newDoctor);
}

/**
 * Update an existing doctor.
 * Java integration: PUT /api/doctors/{id} (requires new backend method).
 * @param {number} id
 * @param {{ name: string, specilization: string }} doctorData
 * @returns {Promise<Object>}
 */
async function updateDoctor(id, doctorData) {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/doctors/${id}`, {
  //   method: 'PUT',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(doctorData)
  // }).then(res => res.json());

  const index = sampleDoctors.findIndex(d => d.id === id);
  if (index === -1) throw new Error('Doctor not found');
  sampleDoctors[index] = { id, ...doctorData };
  return Promise.resolve(sampleDoctors[index]);
}

/**
 * Delete a doctor by ID.
 * Java integration: DELETE /api/doctors/{id} (requires new backend method).
 * @param {number} id
 * @returns {Promise<boolean>}
 */
async function deleteDoctor(id) {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/doctors/${id}`, { method: 'DELETE' })
  //   .then(res => res.ok);

  const index = sampleDoctors.findIndex(d => d.id === id);
  if (index === -1) throw new Error('Doctor not found');
  sampleDoctors.splice(index, 1);
  return Promise.resolve(true);
}

/**
 * Fetch all appointments.
 * Java integration: GET /api/appointments
 * @returns {Promise<Array>}
 */
async function fetchAppointments() {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/appointments`).then(res => res.json());

  return Promise.resolve([...sampleAppointments]);
}

/**
 * Book a new appointment.
 * Java integration: POST /api/appointments
 * Maps to HospitalManagementSystem.bookAppointment() logic:
 *   - Validates patient exists (Patient.getPatientByID)
 *   - Validates doctor exists (Doctor.getDoctorByID)
 *   - Checks doctor availability (checkDoctorAvailability)
 * @param {{ patients_id: number, doctor_id: number, appointment_date: string }} data
 * @returns {Promise<Object>}
 */
async function bookAppointment(data) {
  // --- JAVA BACKEND INTEGRATION POINT ---
  // return fetch(`${API_BASE_URL}/appointments`, {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(data)
  // }).then(res => {
  //   if (!res.ok) return res.json().then(err => Promise.reject(err));
  //   return res.json();
  // });

  const patient = samplePatients.find(p => p.id === data.patients_id);
  const doctor = sampleDoctors.find(d => d.id === data.doctor_id);

  if (!patient) throw new Error('Patient does not exist.');
  if (!doctor) throw new Error('Doctor does not exist.');

  const conflict = sampleAppointments.some(
    a => a.doctor_id === data.doctor_id && a.appointment_date === data.appointment_date
  );
  if (conflict) throw new Error('Doctor not available on this date.');

  const appointment = {
    id: nextAppointmentId++,
    ...data,
    patientName: patient.name,
    doctorName: doctor.name
  };
  sampleAppointments.push(appointment);
  return Promise.resolve(appointment);
}

/* ============================================================
   UI HELPER FUNCTIONS
   ============================================================ */

/** Show a toast notification */
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;

  const icons = {
    success: 'fa-circle-check',
    error: 'fa-circle-xmark',
    info: 'fa-circle-info',
    warning: 'fa-triangle-exclamation'
  };

  toast.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i> ${message}`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(40px)';
    toast.style.transition = '0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

/** Navigate to a section by ID */
function navigateTo(sectionId) {
  document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));

  const section = document.getElementById(sectionId);
  const link = document.querySelector(`.nav-link[data-section="${sectionId}"]`);

  if (section) section.classList.add('active');
  if (link) link.classList.add('active');

  document.getElementById('navLinks').classList.remove('open');
  document.getElementById('navToggle').setAttribute('aria-expanded', 'false');

  window.location.hash = sectionId;
}

/** Clear validation errors on a form */
function clearFormErrors(form) {
  form.querySelectorAll('.invalid').forEach(el => el.classList.remove('invalid'));
  form.querySelectorAll('.error-msg').forEach(el => { el.textContent = ''; });
}

/** Validate a single field and show error */
function validateField(field, errorEl, rules) {
  const value = field.type === 'number' ? field.value : field.value.trim();
  let message = '';

  if (rules.required && !value) {
    message = 'This field is required.';
  } else if (rules.minLength && value.length < rules.minLength) {
    message = `Minimum ${rules.minLength} characters required.`;
  } else if (rules.min !== undefined && Number(value) < rules.min) {
    message = `Value must be at least ${rules.min}.`;
  } else if (rules.max !== undefined && Number(value) > rules.max) {
    message = `Value must be at most ${rules.max}.`;
  } else if (rules.pattern && !rules.pattern.test(value)) {
    message = rules.patternMessage || 'Invalid format.';
  }

  if (message) {
    field.classList.add('invalid');
    errorEl.textContent = message;
    return false;
  }

  field.classList.remove('invalid');
  errorEl.textContent = '';
  return true;
}

/** Validate patient form fields */
function validatePatientForm() {
  const name = document.getElementById('patientName');
  const age = document.getElementById('patientAge');
  const gender = document.getElementById('patientGender');

  const validName = validateField(name, document.getElementById('patientNameError'), {
    required: true,
    minLength: 2
  });
  const validAge = validateField(age, document.getElementById('patientAgeError'), {
    required: true,
    min: 0,
    max: 150
  });
  const validGender = validateField(gender, document.getElementById('patientGenderError'), {
    required: true
  });

  return validName && validAge && validGender;
}

/** Validate doctor form fields */
function validateDoctorForm() {
  const name = document.getElementById('doctorName');
  const spec = document.getElementById('doctorSpecialization');

  const validName = validateField(name, document.getElementById('doctorNameError'), {
    required: true,
    minLength: 2
  });
  const validSpec = validateField(spec, document.getElementById('doctorSpecializationError'), {
    required: true,
    minLength: 2
  });

  return validName && validSpec;
}

/** Validate appointment form fields */
function validateAppointmentForm() {
  const patientId = document.getElementById('appointmentPatientId');
  const doctorId = document.getElementById('appointmentDoctorId');
  const date = document.getElementById('appointmentDate');

  const validPatient = validateField(patientId, document.getElementById('appointmentPatientIdError'), {
    required: true,
    min: 1
  });
  const validDoctor = validateField(doctorId, document.getElementById('appointmentDoctorIdError'), {
    required: true,
    min: 1
  });
  const validDate = validateField(date, document.getElementById('appointmentDateError'), {
    required: true
  });

  return validPatient && validDoctor && validDate;
}

/** Open delete confirmation modal */
function openDeleteModal(message, onConfirm) {
  document.getElementById('deleteModalMessage').textContent = message;
  document.getElementById('deleteModal').hidden = false;
  deleteCallback = onConfirm;
}

/** Close delete confirmation modal */
function closeDeleteModal() {
  document.getElementById('deleteModal').hidden = true;
  deleteCallback = null;
}

/* ============================================================
   RENDER FUNCTIONS
   ============================================================ */

/** Update dashboard statistics */
function updateDashboardStats(patients, doctors, appointments) {
  document.getElementById('statPatients').textContent = patients.length;
  document.getElementById('statDoctors').textContent = doctors.length;
  document.getElementById('statAppointments').textContent = appointments.length;

  const today = new Date();
  document.getElementById('statToday').textContent = today.toLocaleDateString('en-IN', {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
}

/** Render patients table with optional search filter */
function renderPatientsTable(patients, searchTerm = '') {
  const tbody = document.getElementById('patientsTableBody');
  const empty = document.getElementById('patientsEmpty');
  const term = searchTerm.toLowerCase().trim();

  const filtered = patients.filter(p =>
    !term ||
    String(p.id).includes(term) ||
    p.name.toLowerCase().includes(term) ||
    p.gender.toLowerCase().includes(term) ||
    String(p.age).includes(term)
  );

  tbody.innerHTML = '';

  if (filtered.length === 0) {
    empty.hidden = false;
    return;
  }

  empty.hidden = true;

  filtered.forEach(patient => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${patient.id}</td>
      <td>${escapeHtml(patient.name)}</td>
      <td>${patient.age}</td>
      <td>${escapeHtml(patient.gender)}</td>
      <td>
        <div class="table-actions">
          <button class="btn-edit" data-action="edit-patient" data-id="${patient.id}" title="Edit patient">
            <i class="fa-solid fa-pen"></i> Edit
          </button>
          <button class="btn-delete" data-action="delete-patient" data-id="${patient.id}" title="Delete patient">
            <i class="fa-solid fa-trash"></i> Delete
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(row);
  });
}

/** Render doctors table with optional search filter */
function renderDoctorsTable(doctors, searchTerm = '') {
  const tbody = document.getElementById('doctorsTableBody');
  const empty = document.getElementById('doctorsEmpty');
  const term = searchTerm.toLowerCase().trim();

  const filtered = doctors.filter(d =>
    !term ||
    String(d.id).includes(term) ||
    d.name.toLowerCase().includes(term) ||
    d.specilization.toLowerCase().includes(term)
  );

  tbody.innerHTML = '';

  if (filtered.length === 0) {
    empty.hidden = false;
    return;
  }

  empty.hidden = true;

  filtered.forEach(doctor => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${doctor.id}</td>
      <td>${escapeHtml(doctor.name)}</td>
      <td>${escapeHtml(doctor.specilization)}</td>
      <td>
        <div class="table-actions">
          <button class="btn-edit" data-action="edit-doctor" data-id="${doctor.id}" title="Edit doctor">
            <i class="fa-solid fa-pen"></i> Edit
          </button>
          <button class="btn-delete" data-action="delete-doctor" data-id="${doctor.id}" title="Delete doctor">
            <i class="fa-solid fa-trash"></i> Delete
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(row);
  });
}

/** Render appointments table with optional search filter */
function renderAppointmentsTable(appointments, searchTerm = '') {
  const tbody = document.getElementById('appointmentsTableBody');
  const empty = document.getElementById('appointmentsEmpty');
  const term = searchTerm.toLowerCase().trim();

  const filtered = appointments.filter(a =>
    !term ||
    String(a.id).includes(term) ||
    (a.patientName && a.patientName.toLowerCase().includes(term)) ||
    (a.doctorName && a.doctorName.toLowerCase().includes(term)) ||
    a.appointment_date.includes(term)
  );

  tbody.innerHTML = '';

  if (filtered.length === 0) {
    empty.hidden = false;
    return;
  }

  empty.hidden = true;

  filtered.forEach(appt => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${appt.id}</td>
      <td>${escapeHtml(appt.patientName || `Patient #${appt.patients_id}`)}</td>
      <td>${escapeHtml(appt.doctorName || `Doctor #${appt.doctor_id}`)}</td>
      <td>${formatDate(appt.appointment_date)}</td>
    `;
    tbody.appendChild(row);
  });
}

/** Prevent XSS when rendering user-provided strings */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/** Format YYYY-MM-DD for display */
function formatDate(dateStr) {
  const date = new Date(dateStr + 'T00:00:00');
  return date.toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });
}

/* ============================================================
   DATA REFRESH
   ============================================================ */

/** Load all data from API placeholders and refresh UI */
async function refreshAllData() {
  try {
    const [patients, doctors, appointments] = await Promise.all([
      fetchPatients(),
      fetchDoctors(),
      fetchAppointments()
    ]);

    updateDashboardStats(patients, doctors, appointments);
    renderPatientsTable(patients, document.getElementById('patientSearch').value);
    renderDoctorsTable(doctors, document.getElementById('doctorSearch').value);
    renderAppointmentsTable(appointments, document.getElementById('appointmentSearch').value);
  } catch (error) {
    showToast('Failed to load data. Check backend connection.', 'error');
    console.error('refreshAllData error:', error);
  }
}

/* ============================================================
   PATIENT FORM HANDLERS
   ============================================================ */

function resetPatientForm() {
  const form = document.getElementById('patientForm');
  form.reset();
  clearFormErrors(form);
  document.getElementById('patientEditId').value = '';
  document.getElementById('patientFormTitle').innerHTML =
    '<i class="fa-solid fa-user-plus"></i> Add Patient';
  document.getElementById('patientSubmitBtn').innerHTML =
    '<i class="fa-solid fa-save"></i> Save Patient';
  document.getElementById('patientCancelBtn').hidden = true;
}

async function handlePatientFormSubmit(event) {
  event.preventDefault();
  const form = event.target;
  clearFormErrors(form);

  if (!validatePatientForm()) {
    showToast('Please fix the highlighted errors.', 'warning');
    return;
  }

  const editId = document.getElementById('patientEditId').value;
  const patientData = {
    name: document.getElementById('patientName').value.trim(),
    age: parseInt(document.getElementById('patientAge').value, 10),
    gender: document.getElementById('patientGender').value
  };

  try {
    if (editId) {
      await updatePatient(parseInt(editId, 10), patientData);
      showToast('Patient updated successfully.', 'success');
    } else {
      await addPatient(patientData);
      showToast('Patient added successfully.', 'success');
    }
    resetPatientForm();
    await refreshAllData();
  } catch (error) {
    showToast(error.message || 'Failed to save patient.', 'error');
  }
}

function startEditPatient(id) {
  fetchPatients().then(patients => {
    const patient = patients.find(p => p.id === id);
    if (!patient) {
      showToast('Patient not found.', 'error');
      return;
    }

    document.getElementById('patientEditId').value = patient.id;
    document.getElementById('patientName').value = patient.name;
    document.getElementById('patientAge').value = patient.age;
    document.getElementById('patientGender').value = patient.gender;
    document.getElementById('patientFormTitle').innerHTML =
      '<i class="fa-solid fa-pen"></i> Edit Patient';
    document.getElementById('patientSubmitBtn').innerHTML =
      '<i class="fa-solid fa-save"></i> Update Patient';
    document.getElementById('patientCancelBtn').hidden = false;

    navigateTo('patients');
    document.getElementById('patientName').focus();
  });
}

function confirmDeletePatient(id) {
  fetchPatients().then(patients => {
    const patient = patients.find(p => p.id === id);
    if (!patient) return;

    openDeleteModal(
      `Delete patient "${patient.name}" (ID: ${patient.id})? This action cannot be undone.`,
      async () => {
        try {
          await deletePatient(id);
          showToast('Patient deleted successfully.', 'success');
          await refreshAllData();
        } catch (error) {
          showToast(error.message || 'Failed to delete patient.', 'error');
        }
      }
    );
  });
}

/* ============================================================
   DOCTOR FORM HANDLERS
   ============================================================ */

function resetDoctorForm() {
  const form = document.getElementById('doctorForm');
  form.reset();
  clearFormErrors(form);
  document.getElementById('doctorEditId').value = '';
  document.getElementById('doctorFormTitle').innerHTML =
    '<i class="fa-solid fa-user-plus"></i> Add Doctor';
  document.getElementById('doctorSubmitBtn').innerHTML =
    '<i class="fa-solid fa-save"></i> Save Doctor';
  document.getElementById('doctorCancelBtn').hidden = true;
}

async function handleDoctorFormSubmit(event) {
  event.preventDefault();
  const form = event.target;
  clearFormErrors(form);

  if (!validateDoctorForm()) {
    showToast('Please fix the highlighted errors.', 'warning');
    return;
  }

  const editId = document.getElementById('doctorEditId').value;
  const doctorData = {
    name: document.getElementById('doctorName').value.trim(),
    specilization: document.getElementById('doctorSpecialization').value.trim()
  };

  try {
    if (editId) {
      await updateDoctor(parseInt(editId, 10), doctorData);
      showToast('Doctor updated successfully.', 'success');
    } else {
      await addDoctor(doctorData);
      showToast('Doctor added successfully.', 'success');
    }
    resetDoctorForm();
    await refreshAllData();
  } catch (error) {
    showToast(error.message || 'Failed to save doctor.', 'error');
  }
}

function startEditDoctor(id) {
  fetchDoctors().then(doctors => {
    const doctor = doctors.find(d => d.id === id);
    if (!doctor) {
      showToast('Doctor not found.', 'error');
      return;
    }

    document.getElementById('doctorEditId').value = doctor.id;
    document.getElementById('doctorName').value = doctor.name;
    document.getElementById('doctorSpecialization').value = doctor.specilization;
    document.getElementById('doctorFormTitle').innerHTML =
      '<i class="fa-solid fa-pen"></i> Edit Doctor';
    document.getElementById('doctorSubmitBtn').innerHTML =
      '<i class="fa-solid fa-save"></i> Update Doctor';
    document.getElementById('doctorCancelBtn').hidden = false;

    navigateTo('doctors');
    document.getElementById('doctorName').focus();
  });
}

function confirmDeleteDoctor(id) {
  fetchDoctors().then(doctors => {
    const doctor = doctors.find(d => d.id === id);
    if (!doctor) return;

    openDeleteModal(
      `Delete doctor "${doctor.name}" (ID: ${doctor.id})? This action cannot be undone.`,
      async () => {
        try {
          await deleteDoctor(id);
          showToast('Doctor deleted successfully.', 'success');
          await refreshAllData();
        } catch (error) {
          showToast(error.message || 'Failed to delete doctor.', 'error');
        }
      }
    );
  });
}

/* ============================================================
   APPOINTMENT FORM HANDLER
   ============================================================ */

async function handleAppointmentFormSubmit(event) {
  event.preventDefault();
  const form = event.target;
  clearFormErrors(form);

  if (!validateAppointmentForm()) {
    showToast('Please fix the highlighted errors.', 'warning');
    return;
  }

  const appointmentData = {
    patients_id: parseInt(document.getElementById('appointmentPatientId').value, 10),
    doctor_id: parseInt(document.getElementById('appointmentDoctorId').value, 10),
    appointment_date: document.getElementById('appointmentDate').value
  };

  try {
    await bookAppointment(appointmentData);
    showToast('Appointment booked successfully.', 'success');
    form.reset();
    await refreshAllData();
  } catch (error) {
    showToast(error.message || 'Failed to book appointment.', 'error');
  }
}

/* ============================================================
   EVENT LISTENERS & INITIALIZATION
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  /* Navigation */
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(link.dataset.section);
    });
  });

  document.querySelectorAll('[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => navigateTo(btn.dataset.nav));
  });

  /* Mobile nav toggle */
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');

  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });

  /* Hash-based routing on load */
  const hash = window.location.hash.replace('#', '');
  if (hash && document.getElementById(hash)) {
    navigateTo(hash);
  }

  /* Patient form */
  document.getElementById('patientForm').addEventListener('submit', handlePatientFormSubmit);
  document.getElementById('patientCancelBtn').addEventListener('click', resetPatientForm);

  document.getElementById('patientSearch').addEventListener('input', e => {
    fetchPatients().then(patients => renderPatientsTable(patients, e.target.value));
  });

  /* Doctor form */
  document.getElementById('doctorForm').addEventListener('submit', handleDoctorFormSubmit);
  document.getElementById('doctorCancelBtn').addEventListener('click', resetDoctorForm);

  document.getElementById('doctorSearch').addEventListener('input', e => {
    fetchDoctors().then(doctors => renderDoctorsTable(doctors, e.target.value));
  });

  /* Appointment form */
  document.getElementById('appointmentForm').addEventListener('submit', handleAppointmentFormSubmit);

  document.getElementById('appointmentSearch').addEventListener('input', e => {
    fetchAppointments().then(appts => renderAppointmentsTable(appts, e.target.value));
  });

  /* Set minimum appointment date to today */
  const dateInput = document.getElementById('appointmentDate');
  dateInput.min = new Date().toISOString().split('T')[0];

  /* Table action delegation (Edit / Delete buttons) */
  document.getElementById('patientsTableBody').addEventListener('click', e => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const id = parseInt(btn.dataset.id, 10);
    if (btn.dataset.action === 'edit-patient') startEditPatient(id);
    if (btn.dataset.action === 'delete-patient') confirmDeletePatient(id);
  });

  document.getElementById('doctorsTableBody').addEventListener('click', e => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const id = parseInt(btn.dataset.id, 10);
    if (btn.dataset.action === 'edit-doctor') startEditDoctor(id);
    if (btn.dataset.action === 'delete-doctor') confirmDeleteDoctor(id);
  });

  /* Delete modal */
  document.getElementById('deleteModalClose').addEventListener('click', closeDeleteModal);
  document.getElementById('deleteModalCancel').addEventListener('click', closeDeleteModal);
  document.getElementById('deleteModalConfirm').addEventListener('click', async () => {
    if (deleteCallback) await deleteCallback();
    closeDeleteModal();
  });

  document.getElementById('deleteModal').addEventListener('click', e => {
    if (e.target.id === 'deleteModal') closeDeleteModal();
  });

  /* Real-time validation on blur */
  ['patientName', 'patientAge', 'patientGender'].forEach(id => {
    document.getElementById(id).addEventListener('blur', validatePatientForm);
  });
  ['doctorName', 'doctorSpecialization'].forEach(id => {
    document.getElementById(id).addEventListener('blur', validateDoctorForm);
  });
  ['appointmentPatientId', 'appointmentDoctorId', 'appointmentDate'].forEach(id => {
    document.getElementById(id).addEventListener('blur', validateAppointmentForm);
  });

  /* Initial data load */
  refreshAllData();
});
